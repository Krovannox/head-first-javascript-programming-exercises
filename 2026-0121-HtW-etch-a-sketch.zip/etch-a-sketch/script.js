const mainContainer = document.querySelector("#main-container");

let gridSize = 16;

for (let i = 0; i < (gridSize * gridSize); i++) {
    const box = document.createElement("div");
    box.style.width = "calc(100% / 16)";
    box.style.border = "1px solid red";
    box.style.aspectRatio = "1 / 1";
    mainContainer.appendChild(box);
}

const mainContainerStyle = {
    display: "flex",
    flexWrap: "wrap",
    backgroundColor: "gray",
    border: "10px solid blue",
    width: "95vmin",
    height: "95vmin"
}

Object.assign(mainContainer.style, mainContainerStyle);