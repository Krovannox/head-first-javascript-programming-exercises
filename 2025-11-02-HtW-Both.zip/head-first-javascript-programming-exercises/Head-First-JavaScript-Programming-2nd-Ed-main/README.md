Code for Head First JavaScript Programming 2nd Ed, 
by Elisabeth Robson and Eric Freeman.
Published in 2024.

https://wickedlysmart.com/hfjs


