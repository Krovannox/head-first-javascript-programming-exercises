// 1. Start the game
// A. Place a computer battleship in a random location on the grid.
// Generate ship with 3 contiguous grids
let shipGridOne = Math.floor(Math.random() * 7) + 1;
let shipGridTwo;
let shipGridThree;

if (shipGridOne === 1) {
    shipGridTwo = 2;
    shipGridThree = 3;
} else if (shipGridOne === 7) {
    shipGridTwo = 6;
    shipGridThree = 5;
} else {
    shipGridTwo = shipGridOne - 1;
    shipGridThree = shipGridOne + 1;
}

console.log(`Ship in: [${shipGridOne}] [${shipGridTwo}] [${shipGridThree}]`);
console.log('-');

// 2. Game begins. In a loop, prompt the user for a guess, check if it hit, missed or sunk the ship.

let winningCondition = 0;
let userTries = 0;

while (winningCondition === 0) {
    // Get user guess and convert it to Number:
    let userGuess = Number(prompt('Input your guess (1 to 7): '));
    userTries = userTries + 1;

    // Change the value if hit:
    switch (userGuess) {
        case shipGridOne:
            shipGridOne = 'HIT';
            break;
        case shipGridTwo:
            shipGridTwo = 'HIT';
            break;
        case shipGridThree:
            shipGridThree = 'HIT';
            break;
    }

    // Show user guess:
    console.log(`User guess: -${userGuess}-`);
    // Show grid values:
    console.log(`Grid values: [A = ${shipGridOne}] - [B = ${shipGridTwo}] - [C = ${shipGridThree}]`)
    // Show status of Ship Grid:
    console.log(`Grid status: || ${(shipGridOne != 'HIT' ? 'Online' : 'HIT')} || ${(shipGridTwo != 'HIT' ? 'Online' : 'HIT')} || ${(shipGridThree != 'HIT' ? 'Online' : 'HIT')} ||`);
    console.log(winningCondition);
    console.log('-');

    if ((shipGridOne === 'HIT') && (shipGridTwo === 'HIT') && (shipGridThree === 'HIT')) {
        winningCondition = 1;
    }
}

// 3. Game finish by giving a rating bases on number of guesses.

console.log(`You won!, it took you ${userTries} tries.`)

if (userTries >= 12) {
    console.log('D Rank');
} else if (userTries >= 9) {
    console.log('C Rank');
} else if (userTries >= 7) {
    console.log('B Rank');
} else if (userTries >= 4) {
    console.log('A Rank');
} else if (userTries >= 3) {
    console.log('S Rank');
}