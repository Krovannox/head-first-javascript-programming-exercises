// Object styles
const mainContainerStyle = {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
    border: "5px solid red",
    gap: "5px"
}

const gridContainerStyle = {
    display: "flex",
    flexWrap: "wrap",
    border: "5px solid black",
    width: "80vmin",
    height: "80vmin",
    flex: "0 1 auto"
}

const buttonStyle = {
    padding: "15px",
}

// mainContainer is used to align the gridContainer in the center of the page using flexbox
const mainContainer = document.querySelector("#main-container");
Object.assign(mainContainer.style, mainContainerStyle);

// gridContainer is used to wrap the grid and adjust the size of the boxes using aspect ratio
const gridContainer = document.querySelector("#grid-container");

// Create the grid boxes and asign the style before being appended
function generateGrid(gridSize) {
    
    for (let i = 0; i < (gridSize * gridSize); i++) {
        console.log(gridSize); // FOR TESTING - Add a prompt inside the function for testing?
        const gridBox = document.createElement("div");
        gridBox.classList.add("grid-box");

        const gridBoxStyle = {
            border: "1px solid green",
            width: `calc(100% / ${gridSize})`,
            aspectRatio: "1 / 1",
        }

        Object.assign(gridBox.style, gridBoxStyle);

        gridContainer.appendChild(gridBox);
    }

    Object.assign(gridContainer.style, gridContainerStyle);
}

generateGrid(gridSize = 16);

// RGB randomizer
function randomizeRGB() {
    let r = Math.floor(Math.random() * 266);
    let g = Math.floor(Math.random() * 266);
    let b = Math.floor(Math.random() * 266);
    return `rgb(${r}, ${g}, ${b})`;
}

// Event listener for the boxes in the grid
gridContainer.addEventListener("mouseover", (e) => {
    if (!e.target.classList.contains("grid-box")) return;

    e.target.style.backgroundColor = randomizeRGB();
});

// Create button for changing the grid size and insert it in mainContainer before the the gridContainer
const button = document.createElement("button");
button.textContent = "Change the grid size";
button.setAttribute("type", "button");

Object.assign(button.style, buttonStyle);

mainContainer.insertBefore(button, gridContainer);

// Event listener for creating a new grid using the button
button.addEventListener("click", () => {
    let newGridSize = Number(prompt("Chose the size of the grid: "));
    
    if (newGridSize > 100) {
        alert("The maximum size allowed is 100");
    } else {
        gridContainer.innerHTML = "";
        generateGrid(newGridSize);
    }    
});