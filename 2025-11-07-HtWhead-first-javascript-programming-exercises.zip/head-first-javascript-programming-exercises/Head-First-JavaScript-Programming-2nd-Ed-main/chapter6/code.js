let access = document.getElementById("code9");
let code = access.innerHTML; 
code = code + " midnight"; 
alert(code);
